const crypto = require('crypto');
const { privateKey } = require('./rsaKeyGen');

function rsaDecrypt(encryptedText) {
  const decrypted = crypto.privateDecrypt({
    key: privateKey,
    padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
    oaepHash: 'sha256'
  }, Buffer.from(encryptedText, 'base64'));
  return decrypted.toString();
}

module.exports = rsaDecrypt;
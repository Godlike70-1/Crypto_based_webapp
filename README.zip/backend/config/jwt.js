const jwtSecret = process.env.JWT_SECRET;
const expiresIn = '15m';

module.exports = { jwtSecret, expiresIn };
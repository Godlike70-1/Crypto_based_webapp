const crypto = require('crypto');

if (!process.env.AES_SECRET) {
  throw new Error('AES_KEY is not set in environment variables');
}

const aesKey = crypto
  .createHash('sha256')
  .update(process.env.AES_SECRET)
  .digest();

module.exports = { aesKey };

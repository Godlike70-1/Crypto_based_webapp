require('dotenv').config();
const express = require('express');
// const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require("https");
const fs = require("fs");
// const path = require("path");

module.exports = (app) => {
  const keyPath = path.join(__dirname, "kaka.com-key.pem");
  const certPath = path.join(__dirname, "kaka.com.pem");

  const options = {
    key: fs.readFileSync(keyPath),
    cert: fs.readFileSync(certPath),
  };

  return https.createServer(options, app);
};

const db = require('./config/db');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ---------------- ROUTES ----------------

// Auth challenge (certificate login)
const authChallengeRoutes = require('./routes/authChallenge');
app.use('/auth', authChallengeRoutes);

// Existing routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api', require('./routes/dashboard'));
app.use('/api', require('./routes/checkout'));

// E-commerce
app.use('/api', require('./routes/categories'));
app.use('/api', require('./routes/products'));
app.use('/api', require('./routes/cart'));
app.use('/api', require('./routes/order'));

// Certificate-protected route
const certAuth = require('./middleware/certAuth');
app.get('/secure/profile', certAuth, (req, res) => {
  res.json({
    message: 'Certificate authenticated',
    subject: req.certSubject
  });
});

// Landing page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ---------------- DB INIT ----------------
const schema = fs.readFileSync(
  path.join(__dirname, '../database/schema.sql'),
  'utf8'
);

db.exec(schema, (err) => {
  if (err) console.error('DB init error:', err);
});

// ---------------- HTTP → HTTPS ----------------
http.createServer((req, res) => {
  res.writeHead(301, {
    Location: `https://${req.headers.host}${req.url}`
  });
  res.end();
}).listen(80, () => console.log('HTTP redirect on port 80'));

// ---------------- HTTPS ----------------
const httpsServer = require('./httpsServer')(app);
httpsServer.listen(443, () => console.log('HTTPS server on port 443'));

const crypto = require('crypto');
const db = require('../config/db');

/**
 * Generate SHA-256 fingerprint from PEM certificate
 */
function getFingerprint(certPem) {
  return crypto
    .createHash('sha256')
    .update(certPem)
    .digest('hex');
}

/**
 * Certificate Authentication Middleware
 */
function certAuth(req, res, next) {
  const cert = req.socket.getPeerCertificate();

  // 1️⃣ No certificate
  if (!cert || !cert.raw) {
    return res.status(401).json({ error: 'Client certificate required' });
  }

  // 2️⃣ Convert cert to PEM
  const certPem =
    '-----BEGIN CERTIFICATE-----\n' +
    cert.raw.toString('base64').match(/.{1,64}/g).join('\n') +
    '\n-----END CERTIFICATE-----';

  // 3️⃣ Generate fingerprint
  const fingerprint = getFingerprint(certPem);

  // 4️⃣ Check revocation / status in DB
  db.get(
    'SELECT status FROM user_certificates WHERE fingerprint = ?',
    [fingerprint],
    (err, row) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'DB error' });
      }

      if (!row || row.status === 'revoked') {
        return res.status(403).json({ error: 'Certificate revoked' });
      }

      // 5️⃣ Certificate valid → allow access
      req.certFingerprint = fingerprint;
      next();
    }
  );
}

/**
 * 🚨 THIS LINE IS CRITICAL 🚨
 * This is what Express expects when you `require()` the file
 */
module.exports = certAuth;

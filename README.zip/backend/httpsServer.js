const https = require("https");
const fs = require("fs");
const path = require("path");

module.exports = (app) => {
  const keyPath = path.join(__dirname, "../kaka.com-key.pem");
  const certPath = path.join(__dirname, "../kaka.com.pem");

  const options = {
    key: fs.readFileSync(keyPath),
    cert: fs.readFileSync(certPath),
  };

  return https.createServer(options, app);
};

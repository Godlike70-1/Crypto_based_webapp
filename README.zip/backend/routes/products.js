const express = require('express');
const db = require('../config/db');
const auth = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');

const router = express.Router();
const priceRe = /^\d+(\.\d{1,2})?$/;

// Public list
router.get('/products', (req, res) => {
  const categoryId = req.query.categoryId ? Number(req.query.categoryId) : null;
  const q = (req.query.q || '').trim();

  const where = ['is_active = 1'];
  const params = [];

  if (categoryId) {
    where.push('category_id = ?');
    params.push(categoryId);
  }
  if (q) {
    where.push('(name LIKE ? OR description LIKE ?)');
    params.push(`%${q}%`, `%${q}%`);
  }

  const sql = `
    SELECT id, category_id, name, description, price, stock, image_url
    FROM products
    WHERE ${where.join(' AND ')}
    ORDER BY created_at DESC
  `;

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ products: rows });
  });
});

// Public single
router.get('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  db.get(
    `SELECT id, category_id, name, description, price, stock, image_url, is_active
     FROM products WHERE id = ?`,
    [id],
    (err, row) => {
      if (err) return res.status(500).json({ error: 'DB error' });
      if (!row || row.is_active !== 1) return res.status(404).json({ error: 'Not found' });
      res.json({ product: row });
    }
  );
});

// Admin create
router.post('/products', auth, requireRole('admin'), (req, res) => {
  const {
    category_id = null,
    name = '',
    description = '',
    price = '',
    stock = 0,
    image_url = '',
    is_active = 1
  } = req.body || {};

  const cleanName = String(name).trim();
  const cleanPrice = String(price).trim();
  const cleanStock = Number(stock);

  if (!cleanName) return res.status(400).json({ error: 'Name required' });
  if (!priceRe.test(cleanPrice)) return res.status(400).json({ error: 'Invalid price format' });
  if (!Number.isFinite(cleanStock) || cleanStock < 0) return res.status(400).json({ error: 'Invalid stock' });

  db.run(
    `INSERT INTO products (category_id, name, description, price, stock, image_url, is_active)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [category_id ? Number(category_id) : null, cleanName, String(description), cleanPrice, cleanStock, String(image_url), is_active ? 1 : 0],
    function (err) {
      if (err) return res.status(500).json({ error: 'DB error' });
      res.json({ id: this.lastID });
    }
  );
});

// Admin update
router.put('/products/:id', auth, requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  const fields = [];
  const params = [];
  const setIf = (key, value) => { fields.push(`${key} = ?`); params.push(value); };

  if (req.body?.category_id !== undefined) setIf('category_id', req.body.category_id ? Number(req.body.category_id) : null);
  if (req.body?.name !== undefined) setIf('name', String(req.body.name).trim());
  if (req.body?.description !== undefined) setIf('description', String(req.body.description));
  if (req.body?.price !== undefined) {
    const p = String(req.body.price).trim();
    if (!priceRe.test(p)) return res.status(400).json({ error: 'Invalid price format' });
    setIf('price', p);
  }
  if (req.body?.stock !== undefined) {
    const s = Number(req.body.stock);
    if (!Number.isFinite(s) || s < 0) return res.status(400).json({ error: 'Invalid stock' });
    setIf('stock', s);
  }
  if (req.body?.image_url !== undefined) setIf('image_url', String(req.body.image_url));
  if (req.body?.is_active !== undefined) setIf('is_active', req.body.is_active ? 1 : 0);

  if (fields.length === 0) return res.status(400).json({ error: 'No changes' });

  params.push(id);
  db.run(`UPDATE products SET ${fields.join(', ')} WHERE id = ?`, params, function (err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Updated' });
  });
});

// Admin soft delete
router.delete('/products/:id', auth, requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  db.run('UPDATE products SET is_active = 0 WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Deactivated' });
  });
});

module.exports = router;

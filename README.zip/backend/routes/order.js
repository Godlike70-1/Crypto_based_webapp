const express = require('express');
const db = require('../config/db');
const auth = require('../middleware/authMiddleware');

const router = express.Router();

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve(this);
    });
  });
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)));
  });
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
  });
}
function toNum(x) {
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
}

// Place order from cart
router.post('/orders/place', auth, async (req, res) => {
  const userId = req.user.id;

  try {
    await run('BEGIN TRANSACTION');

    const cart = await all(
      `SELECT ci.product_id, ci.quantity, p.name, p.price, p.stock, p.is_active
       FROM cart_items ci
       JOIN products p ON p.id = ci.product_id
       WHERE ci.user_id = ?`,
      [userId]
    );

    if (cart.length === 0) {
      await run('ROLLBACK');
      return res.status(400).json({ error: 'Cart is empty' });
    }

    for (const item of cart) {
      if (item.is_active !== 1) {
        await run('ROLLBACK');
        return res.status(400).json({ error: `Product not available: ${item.name}` });
      }
      if (Number(item.quantity) > Number(item.stock)) {
        await run('ROLLBACK');
        return res.status(400).json({ error: `Not enough stock for: ${item.name}` });
      }
    }

    const total = cart.reduce((sum, i) => sum + toNum(i.price) * Number(i.quantity), 0).toFixed(2);

    const orderInsert = await run(
      'INSERT INTO orders (user_id, status, total) VALUES (?, ?, ?)',
      [userId, 'placed', total]
    );
    const orderId = orderInsert.lastID;

    for (const item of cart) {
      const unit_price = String(item.price);
      const line_total = (toNum(item.price) * Number(item.quantity)).toFixed(2);

      await run(
        `INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, line_total)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [orderId, item.product_id, item.name, unit_price, item.quantity, line_total]
      );

      const dec = await run(
        `UPDATE products
         SET stock = stock - ?
         WHERE id = ? AND stock >= ?`,
        [item.quantity, item.product_id, item.quantity]
      );

      if (dec.changes === 0) {
        await run('ROLLBACK');
        return res.status(400).json({ error: `Stock changed, try again: ${item.name}` });
      }
    }

    await run('DELETE FROM cart_items WHERE user_id = ?', [userId]);
    await run('COMMIT');

    res.json({ message: 'Order placed', order_id: orderId, total });
  } catch (e) {
    try { await run('ROLLBACK'); } catch {}
    res.status(500).json({ error: 'Order failed' });
  }
});

// List orders
router.get('/orders', auth, (req, res) => {
  db.all(
    'SELECT id, status, total, created_at FROM orders WHERE user_id = ? ORDER BY created_at DESC',
    [req.user.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'DB error' });
      res.json({ orders: rows });
    }
  );
});

// Receipt
router.get('/orders/:id/receipt', auth, async (req, res) => {
  const orderId = Number(req.params.id);
  const userId = req.user.id;

  try {
    const order = await get('SELECT id, user_id, status, total, created_at FROM orders WHERE id = ?', [orderId]);
    if (!order || order.user_id !== userId) return res.status(404).json({ error: 'Not found' });

    const items = await all(
      'SELECT product_id, product_name, unit_price, quantity, line_total FROM order_items WHERE order_id = ?',
      [orderId]
    );

    res.json({ order, items });
  } catch {
    res.status(500).json({ error: 'DB error' });
  }
});

module.exports = router;

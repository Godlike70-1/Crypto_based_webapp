const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const db = require('../config/db');
const certAuth = require('../middleware/certAuth');

router.post('/documents/sign', certAuth, async (req, res) => {
  const { content } = req.body;

  const hash = crypto.createHash('sha256').update(content).digest('hex');

  await db.run(
    `INSERT INTO documents (owner_id, content_hash)
     VALUES (?, ?)`,
    [req.userId || 1, hash]
  );

  res.json({ message: 'Document hash stored', hash });
});

router.post('/documents/verify', async (req, res) => {
  const { content, storedHash } = req.body;

  const hash = crypto.createHash('sha256').update(content).digest('hex');

  res.json({ valid: hash === storedHash });
});

module.exports = router;

const express = require('express');
const db = require('../config/db');
const auth = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');

const router = express.Router();

router.get('/categories', (req, res) => {
  db.all('SELECT id, name FROM categories ORDER BY name ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ categories: rows });
  });
});

router.post('/categories', auth, requireRole('admin'), (req, res) => {
  const name = (req.body?.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Name required' });

  db.run('INSERT INTO categories (name) VALUES (?)', [name], function (err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ id: this.lastID, name });
  });
});

router.put('/categories/:id', auth, requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  const name = (req.body?.name || '').trim();
  if (!id || !name) return res.status(400).json({ error: 'Invalid input' });

  db.run('UPDATE categories SET name = ? WHERE id = ?', [name, id], function (err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Updated' });
  });
});

router.delete('/categories/:id', auth, requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid id' });

  db.run('DELETE FROM categories WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ message: 'Deleted' });
  });
});

module.exports = router;

const express = require('express');
const db = require('../config/db');
const auth = require('../middleware/authMiddleware');

const router = express.Router();

function toNum(x) {
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
}

// View cart
router.get('/cart', auth, (req, res) => {
  const userId = req.user.id;

  const sql = `
    SELECT
      ci.product_id,
      ci.quantity,
      p.name,
      p.price,
      p.stock,
      p.image_url
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    WHERE ci.user_id = ? AND p.is_active = 1
    ORDER BY ci.created_at DESC
  `;

  db.all(sql, [userId], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });

    const items = rows.map(r => ({
      ...r,
      line_total: (toNum(r.price) * Number(r.quantity)).toFixed(2)
    }));

    const total = items.reduce((sum, r) => sum + toNum(r.line_total), 0).toFixed(2);
    res.json({ items, total });
  });
});

// Add / Update item
router.post('/cart/items', auth, (req, res) => {
  const userId = req.user.id;
  const productId = Number(req.body?.product_id);
  const quantity = Number(req.body?.quantity);

  if (!productId || !Number.isFinite(quantity) || quantity <= 0) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  db.get('SELECT id, stock, is_active FROM products WHERE id = ?', [productId], (err, p) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    if (!p || p.is_active !== 1) return res.status(404).json({ error: 'Product not found' });
    if (quantity > p.stock) return res.status(400).json({ error: 'Not enough stock' });

    db.run(
      `INSERT INTO cart_items (user_id, product_id, quantity)
       VALUES (?, ?, ?)
       ON CONFLICT(user_id, product_id) DO UPDATE SET quantity = excluded.quantity`,
      [userId, productId, quantity],
      (err) => {
        if (err) return res.status(500).json({ error: 'DB error' });
        res.json({ message: 'Cart updated' });
      }
    );
  });
});

// Remove item
router.delete('/cart/items/:productId', auth, (req, res) => {
  const userId = req.user.id;
  const productId = Number(req.params.productId);
  if (!productId) return res.status(400).json({ error: 'Invalid product id' });

  db.run('DELETE FROM cart_items WHERE user_id = ? AND product_id = ?', [userId, productId], function (err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'Removed' });
  });
});

module.exports = router;

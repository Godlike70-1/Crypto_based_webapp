const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const { execSync } = require('child_process');

const router = express.Router();
const db = require('../config/db');
const certAuth = require('../middleware/certAuth');

/**
 * STEP 1 — Issue challenge (nonce)
 */
router.post('/challenge', certAuth, (req, res) => {
  const nonce = crypto.randomBytes(32).toString('hex');

  db.run(
    `INSERT INTO auth_challenges (nonce, expires_at)
     VALUES (?, datetime('now', '+5 minutes'))`,
    [nonce],
    (err) => {
      if (err) {
        return res.status(500).json({ error: 'DB error' });
      }

      res.json({ nonce });
    }
  );
});

/**
 * STEP 2 — Verify signed challenge
 */
router.post('/verify', async (req, res) => {
  const { nonce, signature, certPem } = req.body;

  const certFile = '/tmp/user-cert.pem';
  const sigFile = '/tmp/sig.bin';
  const dataFile = '/tmp/data.txt';
  const pubKeyFile = '/tmp/pubkey.pem';

  try {
    fs.writeFileSync(certFile, certPem);
    fs.writeFileSync(sigFile, Buffer.from(signature, 'base64'));
    fs.writeFileSync(dataFile, nonce);

    execSync(`openssl x509 -in ${certFile} -pubkey -noout > ${pubKeyFile}`);
    execSync(`openssl dgst -sha256 -verify ${pubKeyFile} -signature ${sigFile} ${dataFile}`);
  } catch (err) {
    return res.status(401).json({ error: 'Signature verification failed' });
  }

  res.json({ success: true });
});

module.exports = router;

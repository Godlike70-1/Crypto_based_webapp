const express = require('express');
const authMiddleware = require('../middleware/authMiddleware');
const rsaDecrypt = require('../crypto/rsaDecrypt');
const aesEncrypt = require('../crypto/aesEncrypt');
const db = require('../config/db');

const router = express.Router();

router.post('/checkout', authMiddleware, (req, res) => {
  const { name, encryptedCard, pin } = req.body;
  // Decrypt RSA
  const card = rsaDecrypt(encryptedCard);
  // Encrypt AES
  const aesEncryptedCard = aesEncrypt(card);
  // Store (note: name and pin not stored for demo, only encrypted card)
  db.run('INSERT INTO checkout_info (user_id, encrypted_card_data) VALUES (?, ?)', [req.user.id, aesEncryptedCard], (err) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'Checkout processed' });
  });
});

module.exports = router;
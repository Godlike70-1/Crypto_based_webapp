const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { jwtSecret, expiresIn } = require('../config/jwt');
const { publicKey } = require('../crypto/rsaKeyGen');

const router = express.Router();

// Get public key
router.get('/public-key', (req, res) => {
  res.json({ publicKey });
});

// Register
router.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Missing fields' });
  }

  bcrypt.hash(password, 10, (err, hash) => {
    if (err) return res.status(500).json({ error: 'Hashing error' });

    db.run(
      'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
      [username, email, hash],
      (err) => {
        if (err) return res.status(500).json({ error: 'DB error' });
        res.json({ message: 'User registered' });
      }
    );
  });
});

// Login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err || !user) return res.status(401).json({ error: 'Invalid credentials' });

    bcrypt.compare(password, user.password_hash, (err, match) => {
      if (err || !match) return res.status(401).json({ error: 'Invalid credentials' });

      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role || 'user' },
        jwtSecret,
        { expiresIn }
      );

      res.json({ token });
    });
  });
});

module.exports = router;

# Secure Web App

This is a simple educational web application demonstrating asymmetric encryption (RSA), symmetric encryption (AES), hashing (bcrypt), secure authentication (JWT), and session handling over HTTPS.

## Setup
1. Install dependencies: `npm install`
2. Generate self-signed certs: `openssl req -newkey rsa:2048 -nodes -keyout backend/certs/key.pem -x509 -days 365 -out backend/certs/cert.pem -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"`
3. Set .env variables (generate secure values)
4. Run: `npm start`
5. Access: https://localhost (accept self-signed cert warning)

Note: For production, use proper certs. Ports 80/443 may require admin rights; adjust to 3000/3001 if needed.

## Where Encryption is Used
- Asymmetric (RSA): Frontend encrypts credit card with public key; backend decrypts with private key.
- Symmetric (AES): Backend re-encrypts decrypted card with AES-256 and stores in DB.
- Hashing: Passwords hashed with bcrypt before DB storage; compared on login.

## Why Hashing is Used
Hashing protects passwords by storing irreversible representations. Even if DB is compromised, passwords can't be easily retrieved.

## Difference Between Symmetric & Asymmetric Encryption
- Symmetric (AES): Same key for encrypt/decrypt; fast but key sharing is risky.
- Asymmetric (RSA): Public key encrypts, private decrypts; secure key exchange but slower.

## How HTTPS Protects Data
HTTPS encrypts all traffic with TLS, preventing eavesdropping, tampering, and man-in-the-middle attacks. Here, self-signed certs are used for demo; production uses CA-signed.
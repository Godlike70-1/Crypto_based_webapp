const fs = require('fs');
const { execSync } = require('child_process');

const PRIVATE_KEY = './user.key.pem';
const NONCE_FILE = './nonce.txt';
const SIG_FILE = './signature.bin';

// Sign nonce
execSync(`openssl dgst -sha256 -sign ${PRIVATE_KEY} -out ${SIG_FILE} ${NONCE_FILE}`);

const signature = fs.readFileSync(SIG_FILE).toString('base64');
console.log(signature);

function showMsg(text, type = "info") {
  const box = document.getElementById("msg");
  if (!box) return alert(text);
  box.className = `msg ${type}`;
  box.textContent = text;
  box.classList.remove("hidden");
}

function digitsOnly(v) {
  return String(v).replace(/\D/g, "");
}

document.getElementById("checkoutForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const token = localStorage.getItem("token");
  if (!token) {
    showMsg("Please login first", "error");
    return (window.location.href = "login.html");
  }

  const name = document.getElementById("name").value.trim();
  const card = digitsOnly(document.getElementById("card").value);
  const pin = digitsOnly(document.getElementById("pin").value);

  if (!name) return showMsg("Name required", "error");
  if (card.length < 12) return showMsg("Invalid card number", "error");
  if (pin.length < 3) return showMsg("Invalid PIN", "error");

  try {
    showMsg("Encrypting sensitive data…", "info");

    const publicKey = await getPublicKey();

    // ✅ Encrypt BOTH card and PIN
    const encryptedCard = await encryptWithRsa(publicKey, card);
    const encryptedPin = await encryptWithRsa(publicKey, pin);

    // ✅ Show encryption output (important for demo)
    document.getElementById("encryptedCard").value = encryptedCard;
    document.getElementById("encryptedPin").value = encryptedPin;

    showMsg("Sending encrypted payload to server…", "info");

    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({
        name,
        encryptedCard,
        encryptedPin
      })
    });

    const data = await res.json();

    if (!res.ok) throw data;

    showMsg("Checkout successful ✅", "success");
    document.getElementById("checkoutForm").reset();
  } catch (err) {
    showMsg(err?.error || "Checkout failed ❌", "error");
  }
});


function showMsg(text, type = "info") {
  const box = document.getElementById("msg");
  if (!box) return alert(text);
  box.className = `msg ${type}`;
  box.textContent = text;
  box.classList.remove("hidden");
}

function clearMsg() {
  const box = document.getElementById("msg");
  if (!box) return;
  box.classList.add("hidden");
  box.textContent = "";
}
function getToken() { return localStorage.getItem('token'); }

async function api(path, options = {}) {
  const token = getToken();
  const headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw data;
  return data;
}

function moneyStr(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return '₹0.00';
  return `₹${n.toFixed(2)}`;
}

function el(id) { return document.getElementById(id); }

async function loadCategories() {
  const data = await api('/api/categories', { method: 'GET' });
  const categories = data.categories || [];

  const catSelect = el('categorySelect');
  const adminCat = el('pCategory');

  catSelect.innerHTML = `<option value="">All Categories</option>`;
  categories.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = c.name;
    catSelect.appendChild(opt);
  });

  adminCat.innerHTML = `<option value="">No Category</option>`;
  categories.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = c.name;
    adminCat.appendChild(opt);
  });
}

async function loadProducts({ categoryId = '', q = '' } = {}) {
  const params = new URLSearchParams();
  if (categoryId) params.set('categoryId', categoryId);
  if (q) params.set('q', q);

  const data = await api(`/api/products?${params.toString()}`, { method: 'GET' });
  const products = data.products || [];
  const grid = el('productsGrid');

  grid.innerHTML = '';
  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product';
    card.innerHTML = `
      <img src="${p.image_url || ''}" alt="">
      <div>
        <strong>${p.name}</strong>
        <div class="muted small">${p.description || ''}</div>
      </div>
      <div class="row space-between">
        <span><strong>${moneyStr(p.price)}</strong></span>
        <span class="muted small">Stock: ${p.stock}</span>
      </div>
      <div class="row">
        <input type="number" min="1" value="1" style="width: 90px" id="qty-${p.id}">
        <button class="btn" id="add-${p.id}">Add</button>
      </div>
    `;
    grid.appendChild(card);

    card.querySelector(`#add-${p.id}`).addEventListener('click', async () => {
      const qty = Number(card.querySelector(`#qty-${p.id}`).value);
      try {
        await api('/api/cart/items', {
          method: 'POST',
          body: JSON.stringify({ product_id: p.id, quantity: qty })
        });
        await loadCart();
      } catch (e) {
        alert(e?.error || 'Failed to add');
      }
    });
  });
}

async function loadCart() {
  const data = await api('/api/cart', { method: 'GET' });
  const items = data.items || [];
  const total = data.total || '0.00';

  const cartList = el('cartList');
  const cartTotal = el('cartTotal');

  if (items.length === 0) {
    cartList.textContent = 'Cart is empty.';
  } else {
    cartList.innerHTML = items.map(i => `
      <div class="row space-between" style="padding: 8px 0; border-bottom: 1px solid #eee;">
        <div>
          <strong>${i.name}</strong>
          <div class="muted small">₹${Number(i.price).toFixed(2)} × ${i.quantity} = ₹${Number(i.line_total).toFixed(2)}</div>
        </div>
        <button class="btn ghost" data-remove="${i.product_id}">Remove</button>
      </div>
    `).join('');

    cartList.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const pid = btn.getAttribute('data-remove');
        await api(`/api/cart/items/${pid}`, { method: 'DELETE' });
        await loadCart();
      });
    });
  }

  cartTotal.textContent = `Total: ₹${Number(total).toFixed(2)}`;
}

async function loadOrders() {
  const data = await api('/api/orders', { method: 'GET' });
  const orders = data.orders || [];
  const ordersList = el('ordersList');

  if (orders.length === 0) {
    ordersList.textContent = 'No orders yet.';
    return;
  }

  ordersList.innerHTML = orders.map(o => `
    <div class="row space-between" style="padding: 8px 0; border-bottom: 1px solid #eee;">
      <div>
        <strong>Order #${o.id}</strong>
        <div class="muted small">${o.status} • ${new Date(o.created_at).toLocaleString()}</div>
      </div>
      <div class="row">
        <strong>₹${Number(o.total).toFixed(2)}</strong>
        <button class="btn ghost" data-receipt="${o.id}">Receipt</button>
      </div>
    </div>
  `).join('');

  ordersList.querySelectorAll('[data-receipt]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-receipt');
      const receipt = await api(`/api/orders/${id}/receipt`, { method: 'GET' });
      const lines = (receipt.items || []).map(i =>
        `${i.product_name} — ₹${Number(i.unit_price).toFixed(2)} × ${i.quantity} = ₹${Number(i.line_total).toFixed(2)}`
      ).join('\n');
      alert(`Order #${receipt.order.id}\nTotal: ₹${Number(receipt.order.total).toFixed(2)}\n\nItems:\n${lines}`);
    });
  });
}

function showAdminIfAdmin() {
  const token = getToken();
  const payload = token ? window.parseJwt?.(token) : null;
  const panel = el('adminPanel');
  if (!panel) return;

  if (payload?.role === 'admin') {
    panel.classList.remove('hidden');

    el('createCategoryBtn').addEventListener('click', async () => {
      const name = (el('newCategoryName').value || '').trim();
      if (!name) return alert('Enter category name');

      await api('/api/categories', {
        method: 'POST',
        body: JSON.stringify({ name })
      });
      el('newCategoryName').value = '';
      await loadCategories();
      alert('Category created');
    });

    el('createProductBtn').addEventListener('click', async () => {
      const name = (el('pName').value || '').trim();
      const price = (el('pPrice').value || '').trim();
      const stock = Number(el('pStock').value || 0);
      const category_id = el('pCategory').value || '';
      const image_url = (el('pImage').value || '').trim();
      const description = (el('pDesc').value || '').trim();

      if (!name || !price) return alert('Enter product name & price');

      await api('/api/products', {
        method: 'POST',
        body: JSON.stringify({
          name,
          description,
          price,
          stock,
          image_url,
          category_id: category_id ? Number(category_id) : null
        })
      });

      el('pName').value = '';
      el('pPrice').value = '';
      el('pStock').value = '';
      el('pImage').value = '';
      el('pDesc').value = '';

      await loadProducts({});
      alert('Product created');
    });
  }
}

async function placeOrder() {
  try {
    const result = await api('/api/orders/place', { method: 'POST' });
    alert(`Order placed! Order ID: ${result.order_id}\nTotal: ₹${Number(result.total).toFixed(2)}`);
    await loadCart();
    await loadOrders();
  } catch (e) {
    alert(e?.error || 'Failed to place order');
  }
}

(async function main() {
  if (!getToken()) return (window.location.href = 'login.html');

  await loadCategories();
  await loadProducts({});
  await loadCart();
  await loadOrders();
  showAdminIfAdmin();

  el('searchBtn').addEventListener('click', async () => {
    await loadProducts({
      categoryId: el('categorySelect').value || '',
      q: (el('searchInput').value || '').trim()
    });
  });

  el('categorySelect').addEventListener('change', async () => {
    await loadProducts({
      categoryId: el('categorySelect').value || '',
      q: (el('searchInput').value || '').trim()
    });
  });

  el('placeOrderBtn').addEventListener('click', placeOrder);
})();
